import Foundation
import Network

struct TVPreset: Identifiable, Hashable {
    let port: UInt16
    let name: String
    var id: UInt16 { port }
}

// Checks whether the TV answers on the local network. Runs only while Luma is
// in the foreground: iOS does not allow background network polling.
final class TVMonitor: ObservableObject {
    static let presets: [TVPreset] = [
        .init(port: 8001, name: "Samsung (Tizen)"),
        .init(port: 3000, name: "LG (webOS)"),
        .init(port: 8008, name: "Android / Google TV"),
        .init(port: 80, name: "Sony Bravia"),
        .init(port: 1925, name: "Philips"),
        .init(port: 8060, name: "Roku TV")
    ]
    private enum Keys {
        static let enabled = "tvSyncEnabled"
        static let host = "tvHost"
        static let port = "tvPort"
    }
    /// nil = unknown (sync off, no address, or still checking).
    @Published private(set) var tvOn: Bool? = nil
    @Published private(set) var statusText = "Off"
    @Published var enabled: Bool { didSet { UserDefaults.standard.set(enabled, forKey: Keys.enabled); restart() } }
    @Published var host: String { didSet { UserDefaults.standard.set(host, forKey: Keys.host); restart() } }
    @Published var port: UInt16 { didSet { UserDefaults.standard.set(Int(port), forKey: Keys.port); restart() } }

    private var timer: Timer?
    private var active = false
    private var inFlight = false
    private var misses = 0
    private var token = 0
    private let probeQueue = DispatchQueue(label: "com.kamilwhoo.luma.tv-probe")
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 2
        config.timeoutIntervalForResource = 3
        return URLSession(configuration: config)
    }()

    init() {
        let defaults = UserDefaults.standard
        enabled = defaults.bool(forKey: Keys.enabled)
        host = defaults.string(forKey: Keys.host) ?? ""
        let saved = defaults.integer(forKey: Keys.port)
        port = (1...65535).contains(saved) ? UInt16(saved) : 8001
    }

    private var trimmedHost: String? {
        let h = host.trimmingCharacters(in: .whitespacesAndNewlines)
        return h.isEmpty || h.contains(" ") ? nil : h
    }

    func setActive(_ value: Bool) {
        guard value != active else { return }
        active = value; restart()
    }

    private func restart() {
        timer?.invalidate(); timer = nil
        token += 1; inFlight = false; misses = 0
        guard enabled else { tvOn = nil; statusText = "Off"; return }
        guard trimmedHost != nil, NWEndpoint.Port(rawValue: port) != nil else {
            tvOn = nil; statusText = "Enter the TV's IP address"; return
        }
        guard active else { statusText = "Paused while Luma is in the background"; return }
        statusText = "Checking…"
        let t = Timer(timeInterval: 4, repeats: true) { [weak self] _ in self?.probe() }
        RunLoop.main.add(t, forMode: .common)
        timer = t
        // Short delay so typing an IP address does not fire a probe per keystroke.
        let current = token
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            guard let self = self, self.token == current else { return }
            self.probe()
        }
    }

    private func probe() {
        guard !inFlight, let host = trimmedHost, let nwPort = NWEndpoint.Port(rawValue: port) else { return }
        inFlight = true
        let current = token
        let finish: (Bool) -> Void = { [weak self] reachable in
            DispatchQueue.main.async {
                guard let self = self, self.token == current else { return }
                self.inFlight = false
                self.record(reachable)
            }
        }
        if port == 8001 { samsungProbe(host: host, finish: finish) }
        else { tcpProbe(host: host, port: nwPort, finish: finish) }
    }

    private func tcpProbe(host: String, port: NWEndpoint.Port, finish: @escaping (Bool) -> Void) {
        let connection = NWConnection(host: NWEndpoint.Host(host), port: port, using: .tcp)
        var done = false // only touched on probeQueue
        let complete: (Bool) -> Void = { reachable in
            guard !done else { return }
            done = true
            connection.cancel()
            finish(reachable)
        }
        connection.stateUpdateHandler = { state in
            switch state {
            case .ready: complete(true)
            case .failed, .waiting: complete(false)
            default: break
            }
        }
        connection.start(queue: probeQueue)
        probeQueue.asyncAfter(deadline: .now() + 2) { complete(false) }
    }

    // Samsung 2018+ reports PowerState ("on" / "standby"), which is more reliable
    // than reachability because the TV keeps Wi-Fi alive in standby.
    private func samsungProbe(host: String, finish: @escaping (Bool) -> Void) {
        var components = URLComponents()
        components.scheme = "http"; components.host = host; components.port = 8001; components.path = "/api/v2/"
        guard let url = components.url else { finish(false); return }
        session.dataTask(with: url) { data, _, error in
            guard error == nil, let data = data else { finish(false); return }
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let device = json["device"] as? [String: Any],
               let power = device["PowerState"] as? String {
                finish(power.lowercased() == "on")
            } else {
                finish(true)
            }
        }.resume()
    }

    // One answer is enough to switch on; two misses in a row (~8 s) switch off,
    // so a single dropped Wi-Fi packet does not turn the light off.
    private func record(_ reachable: Bool) {
        if reachable {
            misses = 0
            if tvOn != true { tvOn = true }
            statusText = "TV is on"
        } else {
            misses += 1
            if misses >= 2 {
                if tvOn != false { tvOn = false }
                statusText = "TV is off or not reachable"
            }
        }
    }
}
