#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcodebuild -project Luma.xcodeproj -scheme Luma -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/Simulator CODE_SIGNING_ALLOWED=NO build
simulator_id="$(xcrun simctl list devices available --json | python3 -c 'import json,sys; d=json.load(sys.stdin); a=[p for group in d["devices"].values() for p in group if p.get("isAvailable") and "iPhone" in p["name"]]; assert a,"No iPhone simulator installed"; print(a[0]["udid"])')"
if ! xcrun simctl boot "$simulator_id"; then
  xcrun simctl list devices booted | grep -F "$simulator_id"
fi
xcrun simctl bootstatus "$simulator_id" -b
xcrun simctl install "$simulator_id" build/Simulator/Build/Products/Debug-iphonesimulator/Luma.app
xcrun simctl launch --terminate-running-process "$simulator_id" com.kamilwhoo.luma
sleep 3
xcrun simctl spawn "$simulator_id" launchctl list > build/simulator-processes.txt
python3 - <<'PY'
from pathlib import Path
lines=Path('build/simulator-processes.txt').read_text().splitlines()
assert any('com.kamilwhoo.luma' in line and line.split()[0].isdigit() and int(line.split()[0]) > 0 for line in lines), 'Luma exited after launch. Check simulator diagnostics in the build log.'
print('PASS: Luma stayed running after simulator launch.')
PY
xcrun simctl io "$simulator_id" screenshot build/simulator-launch.png
xcrun simctl terminate "$simulator_id" com.kamilwhoo.luma
