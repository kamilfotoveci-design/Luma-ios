# Luma 1.3.0 · build 4

Native SwiftUI Bluetooth remote for Magic Lantern OA21-compatible lights (FFF0/FFF3). iOS 17+, native Liquid Glass on iOS 26+, material fallback and Reduce Transparency support.

## Try holding two colours

1. Close Magic Lantern, power on your light and connect it in Luma.
2. Open Effects and start **Blue + purple fade**, or another factory effect.
3. When you like what the light shows, tap the selected card again, or tap **Try hold · speed 0** above the grid.
4. Observe the light. The app says **hold attempt**, never a confirmed freeze.
5. Adjust Brightness. Luma sends only a brightness packet; it does not resend power, RGB or the effect mode.
6. Tap **Resume** or move Effect speed to send a nonzero speed, without restarting the effect.

Speed 0 is a documented command, but its physical behaviour is firmware-dependent. It may stop, move very slowly, or behave differently. This is an experiment, not guaranteed static two-colour support. A two-colour fade can also be a temporal blend, not two spatial regions. There is no verified command here for choosing arbitrary independent left/right colours, reading a frozen frame, or saving that frame for later. Reconnecting, power cycling or choosing another mode may lose it. Saved colours remain single RGB shades.

## Changes

- Added experimental hold/resume, including a second tap on the selected effect card.
- Effect brightness and speed now send independent adjustment packets rather than restarting the effect.
- Pending adjustments coalesce by type while preserving queued power/mode frames and the other adjustment.
- Shared glass merge distance reduced from 20 to 0 points; effect card gaps increased to 16 points. Lavender/blue glass and the app icon are preserved.
- Stale Bluetooth connect callbacks are ignored. Connection changes cancel pending UI changes and clear the effect selection.
- Added command regression tests to the build, followed by Swift parse checks.

## Build and install

This ZIP contains source, not an IPA.

Upload the **contents of luma-ios** to the repository root, including `.github/workflows/build-ipa.yml`. If your repository already uses a ZIP-extraction workflow, replace `Luma-iOS-project.zip` instead and keep that workflow.

GitHub Actions → Build Luma IPA → Run workflow. Download the `Luma-unsigned-IPA` artifact after a successful run. Extract it and sign/install `Luma-unsigned.ipa` using your sideload tool. An unsigned IPA requires signing before it runs on iPhone.

On a Mac with Xcode 26+, open `Luma.xcodeproj` or run `bash build-ipa.sh`. The script runs packet/queue tests, Swift syntax parsing, a simulator launch check in CI, and then builds and checks the device app.

## Validation limits

The editing environment has no macOS/Xcode or physical OA21. Source structure, plist versions, project references, shell syntax and ZIP integrity were checked locally. Swift compilation, Swift regression tests, rendered iPhone appearance and physical hold behaviour must be verified by the build and your light.

## Other controls

Colour, RGB/HEX, brightness, power, saved shades, factory effects and approximate white temperature from 1800–10000 K. Kelvin colours are RGB approximations, not calibrated CCT or separate white channels. Displayed settings are requested values, not LED readback.

## Protocol references

- https://github.com/home-assistant/core/issues/145934 — captured OA21 colour, brightness, power, speed and effect packets.
- https://gist.github.com/clienthax/5b3cc5fa68f7c4c943f2252eaa21d804 — factory effect IDs.
- https://developer.apple.com/documentation/swiftui/glasseffectcontainer — glass grouping.
