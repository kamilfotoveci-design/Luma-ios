import SwiftUI
import CoreBluetooth
import UIKit

@main
struct LumaApp: App {
    var body: some Scene { WindowGroup { RemoteView().preferredColorScheme(.dark) } }
}

final class LEDRemote: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    @Published var devices: [CBPeripheral] = []
    @Published var connected = false
    @Published var scanning = false
    @Published var connecting = false
    @Published var status = "Connect your Magic Lantern LED"
    @Published var deviceName = "OA21"
    private var central: CBCentralManager?
    private var pendingScan = false
    private var peripheral: CBPeripheral?
    private var characteristic: CBCharacteristic?
    private var queue: [Data] = []
    private var writing = false
    private var generation = 0
    private var scanGeneration = 0
    private var connectTimeout: DispatchWorkItem?
    private let serviceID = CBUUID(string: "FFF0")
    private let writeID = CBUUID(string: "FFF3")
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            status = "Ready to connect"
            if pendingScan { pendingScan = false; scan() }
        case .poweredOff: reset(); status = "Turn on Bluetooth in Settings"
        case .unauthorized: reset(); status = "Allow Bluetooth access in Settings → Luma"
        case .unsupported: reset(); status = "Bluetooth LE is unavailable"
        default: status = "Waiting for Bluetooth…"
        }
    }
    func scan() {
        guard let central = central else {
            pendingScan = true
            status = "Starting Bluetooth…"
            self.central = CBCentralManager(delegate: self, queue: .main)
            return
        }
        guard central.state == .poweredOn else { centralManagerDidUpdateState(central); return }
        scanGeneration += 1
        let scanToken = scanGeneration
        devices = []; scanning = true; status = "Looking for nearby LED controllers…"
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) { [weak self] in
            guard let self = self, self.scanGeneration == scanToken else { return }
            self.stopScan()
        }
    }
    func stopScan() {
        pendingScan = false; scanGeneration += 1; central?.stopScan(); scanning = false
        if peripheral == nil { status = devices.isEmpty ? "No controller found. Close Magic Lantern and try again." : "Choose your LED controller" }
    }
    func centralManager(_ central: CBCentralManager, didDiscover p: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = (p.name ?? advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? "").lowercased()
        let services = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] ?? []
        guard name.contains("oa21") || name.contains("melk") || name.contains("led") || services.contains(serviceID) else { return }
        if !devices.contains(where: { $0.identifier == p.identifier }) { devices.append(p) }
    }
    func connect(_ p: CBPeripheral) {
        stopScan()
        if let old = peripheral { central?.cancelPeripheralConnection(old) }
        reset(); peripheral = p; p.delegate = self; connecting = true
        deviceName = p.name ?? "Magic Lantern LED"; status = "Connecting…"
        central?.connect(p)
        let timeout = DispatchWorkItem { [weak self, weak p] in
            guard let self = self, let p = p, !self.connected, self.peripheral === p else { return }
            self.central?.cancelPeripheralConnection(p); self.reset(); self.status = "Connection timed out. Close Magic Lantern and retry."
        }
        connectTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 12, execute: timeout)
    }
    func centralManager(_ central: CBCentralManager, didConnect p: CBPeripheral) { p.discoverServices([serviceID]) }
    func centralManager(_ central: CBCentralManager, didFailToConnect p: CBPeripheral, error: Error?) {
        guard peripheral === p else { return }; reset(); status = "Could not connect. Close Magic Lantern, move closer and try again."
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral p: CBPeripheral, error: Error?) {
        guard peripheral === p else { return }; reset(); status = "Disconnected"
    }
    func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
        guard peripheral === p else { return }
        guard error == nil, let service = p.services?.first(where: { $0.uuid == serviceID }) else { fail("This controller does not expose the Magic Lantern service"); return }
        p.discoverCharacteristics([writeID], for: service)
    }
    func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard peripheral === p else { return }
        guard error == nil, let c = service.characteristics?.first(where: { $0.uuid == writeID }), c.properties.contains(.write) || c.properties.contains(.writeWithoutResponse) else { fail("A compatible LED control characteristic was not found"); return }
        characteristic = c; connected = true; connecting = false; connectTimeout?.cancel(); status = "Connected · choose a colour to test"
    }
    private func fail(_ message: String) { if let p = peripheral { central?.cancelPeripheralConnection(p) }; reset(); status = message }
    private func reset() {
        connectTimeout?.cancel(); generation += 1; queue.removeAll(); writing = false
        characteristic = nil; peripheral = nil; connected = false; connecting = false
    }
    func disconnect() { if let p = peripheral { central?.cancelPeripheralConnection(p) }; reset(); status = "Disconnected" }
    func apply(on: Bool, rgb: [UInt8], brightness: Int, effect: Int?, speed: Int) {
        guard connected else { status = "Preview only · connect your LED first"; return }
        let brightness = UInt8(clamping: min(100, max(0, brightness)))
        var frames: [[UInt8]] = [[0x7e,4,4,on ? 0xf0 : 0,0,on ? 1 : 0,0xff,0,0xef]]
        if on {
            if let effect = effect { frames.append([0x7e,5,3,UInt8(clamping: effect),6,0xff,0xff,0,0xef]) }
            else { frames.append([0x7e,7,5,3,rgb[0],rgb[1],rgb[2],0x10,0xef]) }
            frames.append([0x7e,4,1,brightness,1,0xff,0xff,0,0xef])
            if effect != nil { frames.append([0x7e,4,2,UInt8(clamping: min(100,max(0,speed))),0xff,0xff,0xff,0,0xef]) }
        }
        queue = frames.map { Data($0) }; status = "Sending…"; pump()
    }
    private func pump() {
        guard !writing, connected, let p = peripheral, let c = characteristic else { return }
        guard !queue.isEmpty else { status = "Sent · requested settings shown"; return }
        let response = c.properties.contains(.write)
        if !response && !p.canSendWriteWithoutResponse { return }
        writing = true
        let data = queue.removeFirst()
        p.writeValue(data, for: c, type: response ? .withResponse : .withoutResponse)
        if !response { next() }
    }
    private func next() {
        let token = generation
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) { [weak self] in
            guard let self = self, self.generation == token else { return }
            self.writing = false; self.pump()
        }
    }
    func peripheral(_ p: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === p else { return }
        if error != nil { queue.removeAll(); writing = false; status = "The light did not accept that change. Disconnect and try again." } else { next() }
    }
    func peripheralIsReady(toSendWriteWithoutResponse p: CBPeripheral) { if peripheral === p { pump() } }
}

struct RemoteView: View {
    @StateObject private var remote = LEDRemote()
    @State private var colour = Color(red: 182.0/255, green: 0, blue: 1)
    @State private var brightness = 80.0
    @State private var speed = 50.0
    @State private var on = true
    @State private var effect: Int? = nil
    @State private var showDevices = false
    @State private var showHelp = false
    @State private var tab = 0
    @State private var pending: DispatchWorkItem?
    @AppStorage("savedColours") private var savedColours = ""
    private let accent = Color(red: 0.78, green: 0.65, blue: 0.98)
    private let presets = ["FF693B","FFB169","EBCF89","89E0C2","4B8DFF","B600FF","FF6584","FFFFFF"]
    private var rgb: [UInt8] {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(colour).getRed(&r, green: &g, blue: &b, alpha: &a)
        return [r,g,b].map { UInt8(clamping: Int(($0*255).rounded())) }
    }
    private var hex: String { rgb.map { String(format: "%02X", Int($0)) }.joined() }
    private var favourites: [String] { savedColours.split(separator: ",").map(String.init) }
    private func color(_ hex: String) -> Color {
        let n = Int(hex, radix: 16) ?? 0
        return Color(red: Double((n>>16)&255)/255, green: Double((n>>8)&255)/255, blue: Double(n&255)/255)
    }
    private func send() {
        pending?.cancel()
        let rgb = self.rgb, on = self.on, brightness = Int(self.brightness), effect = self.effect, speed = Int(self.speed)
        let task = DispatchWorkItem { remote.apply(on: on, rgb: rgb, brightness: brightness, effect: effect, speed: speed) }
        pending = task; DispatchQueue.main.asyncAfter(deadline: .now() + 0.12, execute: task)
    }
    private func choose(_ hex: String) { colour = color(hex); effect = nil; on = true; send() }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    HStack(spacing: 12) {
                        Image(systemName: "lightbulb.led.fill").foregroundStyle(accent).font(.title2)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(remote.deviceName).fontWeight(.semibold)
                            HStack(spacing: 5) {
                                Circle().fill(remote.connected ? Color.green : Color.gray).frame(width: 6,height: 6)
                                Text(remote.connected ? "Bluetooth connected" : remote.connecting ? "Connecting…" : "Not connected")
                            }.font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button(remote.connected ? "Disconnect" : remote.connecting ? "Connecting…" : "Connect") {
                            if remote.connected { remote.disconnect() } else { showDevices = true; remote.scan() }
                        }.buttonStyle(.borderedProminent).tint(accent).foregroundStyle(Color.black).disabled(remote.connecting)
                        .accessibilityHint("Connect directly to your nearby LED over Bluetooth")
                    }
                    if !remote.connected {
                        Label("Preview only. Connect to change your light.", systemImage: "info.circle")
                            .font(.caption).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity,alignment: .leading)
                    }
                    HStack {
                        Text("Light control").font(.title2).fontWeight(.semibold)
                        Spacer()
                        Button { on.toggle(); send() } label: {
                            Image(systemName: "power").font(.title2).frame(width: 52,height: 52)
                                .background(on ? accent.opacity(0.22) : Color.gray.opacity(0.15),in: Circle())
                        }.tint(on ? accent : .gray).accessibilityLabel(on ? "Turn light off" : "Turn light on")
                    }
                    Picker("Mode", selection: $tab) {
                        Text("Colour").tag(0); Text("Effects").tag(1); Text("Saved").tag(2)
                    }.pickerStyle(.segmented)
                    if tab == 0 {
                        VStack(spacing: 18) {
                            RoundedRectangle(cornerRadius: 24).fill(colour).frame(height: 110)
                                .opacity(on ? max(0.08,brightness/100) : 0.08)
                            ColorPicker("Choose colour", selection: $colour, supportsOpacity: false).font(.headline)
                                .onChange(of: colour) { _ in effect = nil; on = true; send() }
                            HStack {
                                Text("#" + hex).font(.system(.subheadline,design: .monospaced)).foregroundStyle(.secondary).accessibilityLabel("Selected colour " + hex)
                                Spacer()
                                Button("＋ Save") {
                                    if !favourites.contains(hex), favourites.count < 16 { savedColours = (favourites + [hex]).joined(separator: ",") }
                                }.tint(accent)
                            }
                        }
                        VStack(spacing: 10) {
                            HStack { Text("Brightness"); Spacer(); Text("\(Int(brightness))%").foregroundStyle(accent) }
                            Slider(value: $brightness,in: 0...100,step: 1).tint(accent).onChange(of: brightness) { _ in send() }.accessibilityLabel("Brightness")
                        }
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4),spacing: 12) {
                            ForEach(presets,id: \.self) { h in Button { choose(h) } label: {
                                Circle().fill(color(h)).frame(width: 42,height: 42).frame(maxWidth: .infinity,minHeight: 48)
                            }.accessibilityLabel("Colour " + h) }
                        }
                    } else if tab == 1 {
                        VStack(spacing: 12) {
                            effectButton("Still colour", value: nil)
                            effectButton("Autoplay", value: 0)
                            effectButton("Magic back", value: 1)
                        }
                        HStack { Text("Speed"); Spacer(); Text("\(Int(speed))%") }
                        Slider(value: $speed,in: 0...100,step: 1).tint(accent).onChange(of: speed) { _ in send() }.accessibilityLabel("Effect speed")
                        Text("Effect appearance depends on the controller.").font(.caption).foregroundStyle(.secondary)
                    } else {
                        if favourites.isEmpty { Text("Save a colour to keep it here.").foregroundStyle(.secondary).padding(.vertical,40) }
                        ForEach(favourites,id: \.self) { h in
                            HStack {
                                Button { choose(h) } label: { HStack { Circle().fill(color(h)).frame(width: 28,height: 28); Text("#" + h); Spacer() } }.tint(.primary)
                                Button { savedColours = favourites.filter { $0 != h }.joined(separator: ",") } label: { Image(systemName: "trash").frame(width: 44,height: 44) }.tint(.secondary).accessibilityLabel("Remove " + h)
                            }
                        }
                    }
                    Text(remote.status).font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity,alignment: .leading)
                }.padding(22)
            }.background(Color(red: 0.063,green: 0.067,blue: 0.075))
            .navigationTitle("✳ luma.").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }.tint(accent) } }
            .sheet(isPresented: $showDevices,onDismiss: { remote.stopScan() }) {
                NavigationStack {
                    List {
                        Section { Text("Power on your LED and close Magic Lantern before connecting.").font(.subheadline).foregroundStyle(.secondary) }
                        ForEach(remote.devices,id: \.identifier) { p in
                            Button(p.name ?? "LED controller") { remote.connect(p); showDevices = false }
                        }
                        if remote.scanning { ProgressView("Scanning…") }
                        Text(remote.status).font(.caption).foregroundStyle(.secondary)
                        Button("Scan again") { remote.scan() }.disabled(remote.scanning)
                    }.navigationTitle("Choose your light")
                    .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { showDevices = false } } }
                }
            }
            .sheet(isPresented: $showHelp) {
                NavigationStack {
                    ScrollView { Text("1. Power on the LED.\n\n2. Close Magic Lantern so it releases Bluetooth.\n\n3. Tap Connect and select OA21 or your controller name.\n\n4. Choose a colour to test.\n\nThis app uses the documented Magic Lantern FFF0/FFF3 protocol. Your controller's compatibility must be tested. The screen shows requested settings; the controller does not report its current colour.\n\nIndependent left/right colours are not implemented: support for your controller has not been established.").padding(24) }
                        .navigationTitle("Connection help").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { showHelp = false } } }
                }
            }
        }
    }
    private func effectButton(_ title: String, value: Int?) -> some View {
        Button { effect = value; on = true; send() } label: {
            HStack { Text(title); Spacer(); if effect == value { Image(systemName: "checkmark") } }
                .padding(16).background(accent.opacity(effect == value ? 0.2 : 0.06),in: RoundedRectangle(cornerRadius: 12))
        }.tint(accent)
    }
}
