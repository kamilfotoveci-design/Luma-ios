import Foundation

// OA21/FFF3 nine-byte packets. Speed zero is documented; a pause guarantee is not.
enum LEDCommands {
    private static func percent(_ value: Int) -> UInt8 { UInt8(min(100,max(0,value))) }
    static func brightness(_ value: Int) -> Data {
        Data([0x7e,4,1,percent(value),1,0xff,0xff,0,0xef])
    }
    static func speed(_ value: Int) -> Data {
        Data([0x7e,4,2,percent(value),0xff,0xff,0xff,0,0xef])
    }
    static func colour(_ rgb: [UInt8]) -> Data {
        precondition(rgb.count == 3)
        return Data([0x7e,7,5,3,rgb[0],rgb[1],rgb[2],0x10,0xef])
    }
    // Preserve pending power/mode frames and the other adjustment. Only the
    // newest unsent adjustment of the same type is useful when dragging sliders.
    static func replacingPendingAdjustment(_ pending: [Data],with frame: Data) -> [Data] {
        precondition(frame.count == 9 && frame[1] == 4 && (frame[2] == 1 || frame[2] == 2))
        return pending.filter { !($0.count == 9 && $0[1] == 4 && $0[2] == frame[2]) } + [frame]
    }
}
