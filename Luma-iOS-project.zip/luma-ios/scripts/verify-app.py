import plistlib
import subprocess
import sys
from pathlib import Path
app=Path(sys.argv[1])
p=plistlib.loads((app/'Info.plist').read_bytes())
assert p.get('NSBluetoothAlwaysUsageDescription'), 'Bluetooth permission text missing'
assert p.get('CFBundleVersion') == '2', 'Unexpected build version'
icon=p.get('CFBundleIcons',{}).get('CFBundlePrimaryIcon',{})
assert icon.get('CFBundleIconName') == 'AppIcon', 'App icon not configured'
assert icon.get('CFBundleIconFiles'), 'Compiled icon files missing'
assert (app/'Assets.car').is_file(), 'Asset catalog missing'
executable=app/p['CFBundleExecutable']
loads=subprocess.check_output(['otool','-l',str(executable)],text=True)
assert '@executable_path/Frameworks' in loads, 'App framework runpath missing'
print('PASS: packaged icon, Bluetooth permission, version and framework runpath.')
print(subprocess.check_output(['otool','-L',str(executable)],text=True))
