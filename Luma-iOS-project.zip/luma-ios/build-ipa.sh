#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "${CI:-}" == "true" ]]; then
  bash scripts/smoke-test.sh
fi
xcodebuild -project Luma.xcodeproj -scheme Luma -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
python3 scripts/verify-app.py build/DerivedData/Build/Products/Release-iphoneos/Luma.app
mkdir -p build/package/Payload
rm -rf build/package/Payload/Luma.app
cp -R build/DerivedData/Build/Products/Release-iphoneos/Luma.app build/package/Payload/Luma.app
cd build/package
rm -f ../Luma-unsigned.ipa
zip -qry ../Luma-unsigned.ipa Payload
printf '\nCreated: build/Luma-unsigned.ipa (requires signing by a sideload tool)\n'
