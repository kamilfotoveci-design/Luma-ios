#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
xcode_major="$(xcodebuild -version | awk '/^Xcode / {split($2,v,"."); print v[1]}')"
if [[ "$xcode_major" -lt 26 ]]; then
  selected_xcode=""
  for candidate in /Applications/Xcode_26.3.app /Applications/Xcode_26.2.app /Applications/Xcode_26.1.1.app /Applications/Xcode_26.0.1.app; do
    if [[ -d "$candidate/Contents/Developer" ]]; then
      selected_xcode="$candidate/Contents/Developer"
      break
    fi
  done
  if [[ -z "$selected_xcode" ]]; then
    printf 'Xcode 26 or later is required for Liquid Glass. Select a supported Xcode and retry.\n' >&2
    exit 1
  fi
  export DEVELOPER_DIR="$selected_xcode"
fi
xcodebuild -version
mkdir -p build
xcrun swiftc -swift-version 5 Luma/LEDCommands.swift tests/CommandTests.swift -o build/command-tests
build/command-tests
xcrun swiftc -frontend -parse -swift-version 5 Luma/*.swift
if [[ "${CI:-}" == "true" ]]; then
  bash scripts/smoke-test.sh
fi
xcodebuild -project Luma.xcodeproj -scheme Luma -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
python3 scripts/verify-app.py build/DerivedData/Build/Products/Release-iphoneos/Luma.app
mkdir -p build/package/Payload
rm -rf build/package/Payload/Luma.app
cp -R build/DerivedData/Build/Products/Release-iphoneos/Luma.app build/package/Payload/Luma.app
cd build/package
rm -f ../Luma-unsigned.ipa
zip -qry ../Luma-unsigned.ipa Payload
printf '\nCreated: build/Luma-unsigned.ipa (requires signing by a sideload tool)\n'
