# Luma pre iPhone

Natívna SwiftUI appka s priamym Bluetooth LE ovládaním Magic Lantern (FFF0/FFF3). Bez Bluefy, webservera a prihlasovania. iOS 17 alebo novší.

## Stav balíka

Toto je zdrojový projekt, NIE hotové IPA. V tomto prostredí nebol k dispozícii macOS/Xcode: iOS kompilácia a test na skutočnom OA21 ešte neprebehli. Priložený build vytvorí nepodpísané IPA; sideload nástroj ho musí podpísať. Potrebuješ vlastný účet a postup podpisovania podľa svojho sideload nástroja.

## Najrýchlejšie cez GitHub Actions

1. Rozbaľ ZIP.
2. Vytvor na GitHube repozitár a nahraj OBSAH priečinka `luma-ios` do koreňa repozitára (nie samotný ZIP).
3. Nahraj aj skrytý priečinok `.github` s workflow súborom. Ak ho Finder nezobrazuje: Cmd + Shift + bodka.
4. Otvor kartu Actions → Build Luma IPA. Build sa spustí pri pushi na main/master; prípadne klikni Run workflow.
5. Keď build úspešne skončí, v časti Artifacts stiahni `Luma-unsigned-IPA`.
6. Rozbaľ stiahnutý artifact ZIP. Vnútri je `Luma-unsigned.ipa`.
7. IPA importuj do svojho nástroja na podpisovanie/sideload (napr. AltStore alebo Sideloadly) a nainštaluj podľa jeho návodu.

macOS runner sa používa v rámci tvojho GitHub účtu a jeho Actions limitov. Build bez podpisu nepotrebuje Apple certifikát v repozitári. Do repozitára nevkladaj Apple heslo ani certifikát.

## Na Macu s Xcode

Nainštaluj Xcode a dokonči jeho prvé spustenie. V Termináli otvor rozbalený priečinok a spusti:

```bash
bash build-ipa.sh
```

Výsledok: `build/Luma-unsigned.ipa`. Ten ešte podpíš svojím sideload nástrojom.

Alternatívne otvor `Luma.xcodeproj`, vyber svoj tím v Signing & Capabilities, pripoj iPhone a spusti appku cez Xcode.

## Ovládanie

Zapni LED a zavri Magic Lantern, aby uvoľnil Bluetooth. V Luma povoľ Bluetooth → Connect → vyber OA21 alebo meno svojho ovládača. Potom skús zmeniť farbu.

Funkcie: zapnúť/vypnúť, výber farby, jas, obľúbené farby, Autoplay/Magic back a rýchlosť efektu. Appka ukazuje požadované hodnoty, nečíta aktuálny stav z ovládača. Bluetooth pripojenie je určené na používanie pri otvorenej appke.

Samostatná modrá ľavá polovica a fialová pravá polovica NIE SÚ implementované. Podpora segmentov pre tento konkrétny ovládač sa nepotvrdila.

## Zdroje protokolu

Príkazy boli implementované podľa zverejnených BLE záznamov:
https://github.com/home-assistant/core/issues/145934

Kompilácia ani reálne hardvérové fungovanie sa v tomto prostredí neoverili. Ak build zlyhá, pošli log z červeného kroku Build unsigned device app.

## Zásady rozhrania

Jedna hlavná akcia: pripojiť LED. Stav pripojenia je vyjadrený textom aj bodkou. Pri odpojení je jasne označený náhľad. Farba a jas sú spolu; efekty a uložené farby sa zobrazujú až vo vlastnej záložke. Po odoslaní sa zobrazuje „Sent · requested settings shown“, čo nepotvrdzuje fyzickú zmenu svetla. Chyby ponúkajú ďalší krok. Ovládanie používa natívne iOS prvky s podporou Dynamic Type a VoiceOver.

## Verzia 1.0.1 / build 2

- Pridaná úplná sada ikon Luma pre iPhone, iPad a App Store.
- Bluetooth manager sa vytvorí až po Connect, nie počas štartu obrazovky.
- Doplnené runpaths a embedding Swift runtime. Bez crash logu nejde o potvrdenú diagnózu pôvodného pádu.
- GitHub CI najprv zostaví simulátorovú verziu a otestuje spustenie, potom zostaví IPA.
- Kontrola výsledného app bundlu overí ikonu, usage description, verziu a runpath.

Pri používaní workflowu na rozbalenie ZIP-u nechaj názov archívu `Luma-iOS-project.zip`. Nahraď v repe pôvodný ZIP a spusti nový build. Staré IPA sa samo nezmení.

Ak appka padá: v iPhone otvor Nastavenia → Súkromie a bezpečnosť → Analýza a vylepšenia → Dáta analýzy. Vyhľadaj najnovší záznam Luma a zdieľaj súbor .ips. Uveď aj nástroj, ktorým bola IPA podpísaná/nainštalovaná. Bez logu sa nedá rozlíšiť runtime chyba od chyby podpisu.

## Verzia 1.2.0 / build 3

- Skutočné SwiftUI Liquid Glass na iOS 26+, GlassEffectContainer a natívny spodný tab bar. Na iOS 17–25 je fallback na systémový material.
- Zohľadnená systémová voľba Reduce Transparency.
- Nová sklenená osemlúčová ikona Luma vo všetkých veľkostiach.
- RGB posuvníky, HEX vstup, scény Warm/Cinema/Night a uložené farby.
- Približná biela podľa Kelvinov: 1800–10000 K, krok 100 K, presety 2200/2700/3000/4000/5000/6500 K. Ide o RGB aproximáciu, nie o kalibrované CCT alebo samostatný biely kanál.
- 12 vstavaných animovaných efektov vrátane dvojfarebných prechodov; mapovanie jednotlivých efektov treba overiť na konkrétnom firmvéri.
- Statické vlastné ľavá/pravá segmenty stále NIE SÚ podporované. Aplikácia na to viditeľne upozorňuje a neposiela vymyslené segmentové príkazy.
- Build skript automaticky vyberie dostupný Xcode 26.3/26.2/26.1.1/26.0.1, ak je predvolený Xcode starší. Vyžaduje Xcode 26+.

Zdroje:
- Apple Liquid Glass: https://developer.apple.com/documentation/swiftui/applying-liquid-glass-to-custom-views
- OA21 effect IDs: https://gist.github.com/clienthax/5b3cc5fa68f7c4c943f2252eaa21d804
- Kelvin → RGB aproximácia, Tanner Helland: https://tannerhelland.com/2012/09/18/convert-temperature-rgb-algorithm-code.html

Ikona: zachovaný symbol Luma, prepracovaný obrazovým nástrojom na priehľadné optické sklo v levanduľových a ľadovo modrých tónoch na tmavom podklade. Vygenerovaný podklad je súčasťou sady AppIcon.

Tento update nebol lokálne skompilovaný: dostupné prostredie nemá macOS/Xcode. GitHub build vykoná kompiláciu a test spustenia simulátora; výsledné IPA treba overiť aj na iPhone.
