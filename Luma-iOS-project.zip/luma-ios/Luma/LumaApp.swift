import SwiftUI
import CoreBluetooth
import UIKit

@main
struct LumaApp: App {
    var body: some Scene { WindowGroup { RemoteView().preferredColorScheme(.dark) } }
}

final class LEDRemote: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    @Published var devices: [CBPeripheral] = []
    @Published var connected = false
    @Published var scanning = false
    @Published var connecting = false
    @Published var status = "Connect your Magic Lantern LED"
    @Published var deviceName = "OA21"
    private var central: CBCentralManager?
    private var pendingScan = false
    private var peripheral: CBPeripheral?
    private var characteristic: CBCharacteristic?
    private var queue: [Data] = []
    private var writing = false
    private var generation = 0
    private var scanGeneration = 0
    private var connectTimeout: DispatchWorkItem?
    private let serviceID = CBUUID(string: "FFF0")
    private let writeID = CBUUID(string: "FFF3")
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            status = "Ready to connect"
            if pendingScan { pendingScan = false; scan() }
        case .poweredOff: reset(); status = "Turn on Bluetooth in Settings"
        case .unauthorized: reset(); status = "Allow Bluetooth access in Settings → Luma"
        case .unsupported: reset(); status = "Bluetooth LE is unavailable"
        default: status = "Waiting for Bluetooth…"
        }
    }
    func scan() {
        guard let central = central else {
            pendingScan = true
            status = "Starting Bluetooth…"
            self.central = CBCentralManager(delegate: self, queue: .main)
            return
        }
        guard central.state == .poweredOn else { centralManagerDidUpdateState(central); return }
        scanGeneration += 1
        let scanToken = scanGeneration
        devices = []; scanning = true; status = "Looking for nearby LED controllers…"
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) { [weak self] in
            guard let self = self, self.scanGeneration == scanToken else { return }
            self.stopScan()
        }
    }
    func stopScan() {
        pendingScan = false; scanGeneration += 1; central?.stopScan(); scanning = false
        if peripheral == nil { status = devices.isEmpty ? "No controller found. Close Magic Lantern and try again." : "Choose your LED controller" }
    }
    func centralManager(_ central: CBCentralManager, didDiscover p: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = (p.name ?? advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? "").lowercased()
        let services = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] ?? []
        guard name.contains("oa21") || name.contains("melk") || name.contains("led") || services.contains(serviceID) else { return }
        if !devices.contains(where: { $0.identifier == p.identifier }) { devices.append(p) }
    }
    func connect(_ p: CBPeripheral) {
        stopScan()
        if let old = peripheral { central?.cancelPeripheralConnection(old) }
        reset(); peripheral = p; p.delegate = self; connecting = true
        deviceName = p.name ?? "Magic Lantern LED"; status = "Connecting…"
        central?.connect(p)
        let timeout = DispatchWorkItem { [weak self, weak p] in
            guard let self = self, let p = p, !self.connected, self.peripheral === p else { return }
            self.central?.cancelPeripheralConnection(p); self.reset(); self.status = "Connection timed out. Close Magic Lantern and retry."
        }
        connectTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 12, execute: timeout)
    }
    func centralManager(_ central: CBCentralManager, didConnect p: CBPeripheral) {
        guard peripheral === p else { return }
        p.discoverServices([serviceID])
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect p: CBPeripheral, error: Error?) {
        guard peripheral === p else { return }; reset(); status = "Could not connect. Close Magic Lantern, move closer and try again."
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral p: CBPeripheral, error: Error?) {
        guard peripheral === p else { return }; reset(); status = "Disconnected"
    }
    func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
        guard peripheral === p else { return }
        guard error == nil, let service = p.services?.first(where: { $0.uuid == serviceID }) else { fail("This controller does not expose the Magic Lantern service"); return }
        p.discoverCharacteristics([writeID], for: service)
    }
    func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard peripheral === p else { return }
        guard error == nil, let c = service.characteristics?.first(where: { $0.uuid == writeID }), c.properties.contains(.write) || c.properties.contains(.writeWithoutResponse) else { fail("A compatible LED control characteristic was not found"); return }
        characteristic = c; connected = true; connecting = false; connectTimeout?.cancel(); status = "Connected · choose a colour to test"
    }
    private func fail(_ message: String) { if let p = peripheral { central?.cancelPeripheralConnection(p) }; reset(); status = message }
    private func reset() {
        connectTimeout?.cancel(); generation += 1; queue.removeAll(); writing = false
        characteristic = nil; peripheral = nil; connected = false; connecting = false
    }
    func disconnect() { if let p = peripheral { central?.cancelPeripheralConnection(p) }; reset(); status = "Disconnected" }
    func apply(on: Bool, rgb: [UInt8], brightness: Int, effect: Int?, speed: Int) {
        guard connected else { status = "Preview only · connect your LED first"; return }
        let brightness = UInt8(clamping: min(100, max(0, brightness)))
        var frames: [[UInt8]] = [[0x7e,4,4,on ? 0xf0 : 0,0,on ? 1 : 0,0xff,0,0xef]]
        if on {
            if let effect = effect { frames.append([0x7e,5,3,UInt8(clamping: effect),6,0xff,0xff,0,0xef]) }
            else { frames.append(Array(LEDCommands.colour(rgb))) }
            frames.append(Array(LEDCommands.brightness(Int(brightness))))
            if effect != nil { frames.append(Array(LEDCommands.speed(speed))) }
        }
        queue = frames.map { Data($0) }; status = "Sending…"; pump()
    }
    // These adjust the running effect without resending its mode or power command.
    func setBrightness(_ value: Int) { enqueueAdjustment(LEDCommands.brightness(value)) }
    func setSpeed(_ value: Int) { enqueueAdjustment(LEDCommands.speed(value)) }
    private func enqueueAdjustment(_ frame: Data) {
        guard connected else { status = "Connect your LED before adjusting the running effect"; return }
        queue = LEDCommands.replacingPendingAdjustment(queue,with:frame)
        status = "Sending…"; pump()
    }
    private func pump() {
        guard !writing, connected, let p = peripheral, let c = characteristic else { return }
        guard !queue.isEmpty else { status = "Sent · requested settings shown"; return }
        let response = c.properties.contains(.write)
        if !response && !p.canSendWriteWithoutResponse { return }
        writing = true
        let data = queue.removeFirst()
        p.writeValue(data, for: c, type: response ? .withResponse : .withoutResponse)
        if !response { next() }
    }
    private func next() {
        let token = generation
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) { [weak self] in
            guard let self = self, self.generation == token else { return }
            self.writing = false; self.pump()
        }
    }
    func peripheral(_ p: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === p else { return }
        if error != nil { queue.removeAll(); writing = false; status = "The light did not accept that change. Disconnect and try again." } else { next() }
    }
    func peripheralIsReady(toSendWriteWithoutResponse p: CBPeripheral) { if peripheral === p { pump() } }
}

private struct LumaGlass: ViewModifier {
    var tint: Color = .white.opacity(0.05)
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @ViewBuilder func body(content: Content) -> some View {
        if reduceTransparency {
            content.background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 26))
        } else {
#if compiler(>=6.2)
            if #available(iOS 26.0, *) {
                content.glassEffect(.regular.tint(tint), in: RoundedRectangle(cornerRadius: 26))
            } else {
                content.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26))
            }
#else
            content.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26))
#endif
        }
    }
}
private extension View {
    func lumaGlass(tint: Color = .white.opacity(0.05)) -> some View { modifier(LumaGlass(tint: tint)) }
}
private struct LumaGlassContainer<Content: View>: View {
    private let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    @ViewBuilder var body: some View {
#if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: 0) { content }
        } else { content }
#else
        content
#endif
    }
}
private struct LightingEffect: Identifiable {
    let id: Int
    let name: String
    let symbol: String
    let colours: [Color]
}

struct RemoteView: View {
    @StateObject private var remote = LEDRemote()
    @State private var colour = Color(red: 182.0/255, green: 0, blue: 1)
    @State private var brightness = 80.0
    @State private var kelvin = 3000.0
    @State private var whiteMode = false
    @State private var speed = 50.0
    @State private var holdRequested = false
    @State private var on = true
    @State private var effect: Int? = nil
    @State private var showDevices = false
    @State private var showHelp = false
    @State private var showRGB = false
    @State private var selectedTab = 0
    @State private var pending: DispatchWorkItem?
    @State private var hexDraft = ""
    @State private var hexError = false
    @AppStorage("savedColours") private var savedColours = ""
    private let accent = Color(red: 0.78, green: 0.65, blue: 0.98)
    private let presets = ["FF693B","FFB169","EBCF89","89E0C2","4B8DFF","B600FF","FF6584","FFFFFF"]
    private let effects: [LightingEffect] = [
        .init(id: 0,name: "Autoplay",symbol: "shuffle",colours: [.pink,.yellow,.blue]),
        .init(id: 1,name: "Magic flow",symbol: "water.waves",colours: [.purple,.cyan]),
        .init(id: 204,name: "Blue + purple fade",symbol: "circle.lefthalf.filled",colours: [.blue,.purple]),
        .init(id: 200,name: "Red + yellow fade",symbol: "circle.lefthalf.filled",colours: [.red,.yellow]),
        .init(id: 201,name: "Red + purple fade",symbol: "circle.lefthalf.filled",colours: [.red,.purple]),
        .init(id: 202,name: "Green + cyan fade",symbol: "circle.lefthalf.filled",colours: [.green,.cyan]),
        .init(id: 203,name: "Green + yellow fade",symbol: "circle.lefthalf.filled",colours: [.green,.yellow]),
        .init(id: 199,name: "Rainbow fade",symbol: "rainbow",colours: [.red,.yellow,.green,.blue,.purple]),
        .init(id: 83,name: "Rainbow wave",symbol: "waveform.path",colours: [.purple,.pink,.orange]),
        .init(id: 205,name: "Red marquee",symbol: "arrow.right",colours: [.red,.orange]),
        .init(id: 207,name: "Blue marquee",symbol: "arrow.right",colours: [.blue,.cyan]),
        .init(id: 210,name: "Purple marquee",symbol: "arrow.right",colours: [.purple,.pink])
    ]
    private func components(_ c: Color) -> [UInt8] {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard UIColor(c).getRed(&r, green: &g, blue: &b, alpha: &a) else { return [0,0,0] }
        return [r,g,b].map { UInt8(clamping: Int(($0*255).rounded())) }
    }
    private var rgb: [UInt8] { components(colour) }
    private var hex: String { rgb.map { String(format: "%02X", Int($0)) }.joined() }
    private var favourites: [String] {
        var seen = Set<String>()
        return savedColours.split(separator: ",").map(String.init).filter { h in
            h.count == 6 && Int(h,radix:16) != nil && seen.insert(h).inserted
        }
    }
    private func color(_ hex: String) -> Color {
        let n = Int(hex, radix: 16) ?? 0
        return Color(red: Double((n>>16)&255)/255, green: Double((n>>8)&255)/255, blue: Double(n&255)/255)
    }
    private func send() {
        pending?.cancel()
        let rgb = self.rgb, on = self.on, brightness = Int(self.brightness), effect = self.effect, speed = Int(self.speed)
        let requestedSpeed = holdRequested ? 0 : speed
        let task = DispatchWorkItem { remote.apply(on: on, rgb: rgb, brightness: brightness, effect: effect, speed: requestedSpeed) }
        pending = task; DispatchQueue.main.asyncAfter(deadline: .now() + 0.12, execute: task)
    }
    private func startEffect(_ id: Int) {
        pending?.cancel(); holdRequested = false
        whiteMode = false; effect = id; on = true
        remote.apply(on: true,rgb: rgb,brightness: Int(brightness),effect: id,speed: Int(speed))
    }
    private func requestHold() {
        guard remote.connected, effect != nil, on else { return }
        pending?.cancel()
        holdRequested.toggle()
        remote.setSpeed(holdRequested ? 0 : Int(speed))
    }
    private var brightnessBinding: Binding<Double> {
        Binding(get: { brightness },set: { brightness = $0; adjustBrightness() })
    }
    private func adjustBrightness() {
        // Never resend a mode, RGB or power frame when dimming a running effect.
        if effect != nil && on { remote.setBrightness(Int(brightness)) }
        else { send() }
    }
    private func choose(_ hex: String, level: Double? = nil) {
        if let level = level { brightness = level }
        colour = color(hex); whiteMode = false; effect = nil; holdRequested = false; on = true; send()
        UISelectionFeedbackGenerator().selectionChanged()
    }
    private var currentTitle: String {
        if whiteMode { return "\(Int(kelvin)) K · RGB white" }
        return effect.flatMap { id in effects.first { $0.id == id }?.name } ?? "Your colour" }
    private var background: some View {
        ZStack {
            Color(red: 0.045,green: 0.045,blue: 0.065)
            RadialGradient(colors: [colour.opacity(on ? 0.3 : 0.035),.clear],center: .topTrailing,startRadius: 15,endRadius: 480)
            RadialGradient(colors: [Color.blue.opacity(0.12),.clear],center: .bottomLeading,startRadius: 0,endRadius: 350)
        }.ignoresSafeArea()
    }
    var body: some View {
        TabView(selection: $selectedTab) {
            page(title: "Light") { colourPage }.tabItem { Label("Light",systemImage: "lightbulb") }.tag(0)
            page(title: "Effects") { effectsPage }.tabItem { Label("Effects",systemImage: "sparkles") }.tag(1)
            page(title: "Saved") { savedPage }.tabItem { Label("Saved",systemImage: "heart") }.tag(2)
        }
        .tint(accent)
        .sheet(isPresented: $showDevices,onDismiss: { remote.stopScan() }) { deviceSheet }
        .sheet(isPresented: $showRGB) { rgbSheet }
        .sheet(isPresented: $showHelp) { helpSheet }
        .onChange(of: remote.connected) { _ in pending?.cancel(); holdRequested = false; effect = nil }
        .onDisappear { pending?.cancel() }
    }
    private func page<Content: View>(title: String,@ViewBuilder content: () -> Content) -> some View {
        NavigationStack {
            ScrollView {
                LumaGlassContainer {
                VStack(spacing: 22) {
                    deviceCard
                    content()
                    Label(remote.status,systemImage: remote.connected ? "antenna.radiowaves.left.and.right" : "info.circle")
                        .font(.caption).foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity,alignment: .leading).padding(.horizontal,4)
                }.padding(.horizontal,20).padding(.top,12).padding(.bottom,30)
                }
            }
            .background(background)
            .navigationTitle(title)
            .toolbar { ToolbarItem(placement: .topBarTrailing) {
                Button { showHelp = true } label: { Image(systemName: "questionmark") }.accessibilityLabel("Connection help")
            } }
        }
    }
    private var deviceCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "lightbulb.led.fill").font(.title3).foregroundStyle(accent)
            VStack(alignment: .leading,spacing: 5) {
                Text(remote.deviceName).font(.subheadline.weight(.semibold))
                HStack(spacing: 5) {
                    Circle().fill(remote.connected ? Color.green : Color.gray).frame(width: 5,height: 5)
                    Text(remote.connected ? "Connected" : remote.connecting ? "Connecting…" : "Not connected")
                }.font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 6)
            if remote.connecting { ProgressView() }
            else {
                Button(remote.connected ? "Disconnect" : "Connect") {
                    pending?.cancel()
                    if remote.connected { remote.disconnect() } else { showDevices = true; remote.scan() }
                }.font(.subheadline.weight(.medium)).buttonStyle(.borderedProminent).buttonBorderShape(.capsule)
            }
        }.padding(17).lumaGlass(tint: accent.opacity(0.09))
    }
    private var colourPage: some View {
        VStack(spacing: 22) {
            ZStack {
                Circle().fill(colour.opacity(on ? max(0.12,brightness/100) : 0.06))
                    .frame(width: 176,height: 176).blur(radius: on ? 32 : 7)
                Circle().fill(LinearGradient(colors: [colour,colour.opacity(0.28)],startPoint: .topLeading,endPoint: .bottomTrailing))
                    .frame(width: 144,height: 144).opacity(on ? 0.95 : 0.16)
                    .overlay(Circle().stroke(.white.opacity(0.22),lineWidth: 1))
                Button { on.toggle(); send() } label: {
                    Image(systemName: "power").font(.system(size: 29,weight: .medium)).foregroundStyle(.white)
                        .frame(width: 72,height: 72)
                        .background(.ultraThinMaterial,in: Circle())
                }.accessibilityLabel(on ? "Turn light off" : "Turn light on")
            }.frame(height: 200).accessibilityElement(children: .contain)
            VStack(spacing: 5) {
                Text(on ? currentTitle : "Light is off").font(.title3.weight(.semibold))
                Text(remote.connected ? "Requested setting · #" + hex : "Preview · connect to control your light")
                    .font(.caption).foregroundStyle(.secondary)
            }
            VStack(spacing: 22) {
                ColorPicker("Colour",selection: Binding(get: { colour },set: { whiteMode = false; colour = $0 }),supportsOpacity: false)
                    .font(.headline).onChange(of: colour) { _ in effect = nil; holdRequested = false; on = true; send() }
                HStack {
                    Button { hexDraft = hex; hexError = false; showRGB = true } label: {
                        Label("RGB / HEX",systemImage: "slider.horizontal.3")
                    }.font(.caption)
                    Spacer()
                    Button {
                        guard !favourites.contains(hex), favourites.count < 24 else { return }
                        savedColours = (favourites + [hex]).joined(separator: ",")
                    } label: { Label(favourites.contains(hex) ? "Saved" : "Save",systemImage: favourites.contains(hex) ? "heart.fill" : "heart") }
                    .font(.caption).disabled(favourites.contains(hex) || favourites.count >= 24)
                }
                VStack(spacing: 10) {
                    HStack { Label("Brightness",systemImage: "sun.max"); Spacer(); Text("\(Int(brightness))%").monospacedDigit().foregroundStyle(.secondary) }.font(.subheadline)
                    Slider(value: brightnessBinding,in: 0...100,step: 1).accessibilityLabel("Brightness")
                }
            }.padding(21).lumaGlass(tint: colour.opacity(0.055))
            whiteCard
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()),count: 8),spacing: 6) {
                ForEach(presets,id: \.self) { h in
                    Button { choose(h) } label: {
                        Circle().fill(color(h)).frame(width: 28,height: 28)
                            .overlay(Circle().stroke(.white.opacity(hex == h ? 0.9 : 0.12),lineWidth: hex == h ? 3 : 1))
                            .frame(maxWidth: .infinity,minHeight: 44)
                    }.accessibilityLabel("Colour " + h)
                }
            }
            VStack(alignment: .leading,spacing: 12) {
                Text("Quick moods").font(.headline)
                HStack(spacing: 10) {
                    mood("Warm",symbol: "sun.horizon",hex: "FFB169",level: 55)
                    mood("Cinema",symbol: "film",hex: "B600FF",level: 35)
                    mood("Night",symbol: "moon",hex: "4B8DFF",level: 15)
                }
            }
        }
    }
    private func temperatureColor(_ value: Double) -> Color {
        let t = min(10000,max(1800,value)) / 100
        let r = t <= 66 ? 255 : 329.698727446 * pow(t-60,-0.1332047592)
        let g = t <= 66 ? 99.4708025861 * log(t)-161.1195681661 : 288.1221695283 * pow(t-60,-0.0755148492)
        let b = t >= 66 ? 255 : (t <= 19 ? 0 : 138.5177312231 * log(t-10)-305.0447927307)
        return Color(red: min(255,max(0,r))/255,green: min(255,max(0,g))/255,blue: min(255,max(0,b))/255)
    }
    private func setKelvin(_ value: Double) {
        kelvin = value; whiteMode = true; effect = nil; holdRequested = false; on = true; colour = temperatureColor(value); send()
    }
    private var whiteCard: some View {
        VStack(alignment: .leading,spacing: 16) {
            HStack {
                Label("White temperature",systemImage: "thermometer.sun")
                Spacer()
                Text("\(Int(kelvin)) K").monospacedDigit().foregroundStyle(whiteMode ? accent : Color.secondary)
            }.font(.subheadline.weight(.medium))
            Slider(value: Binding(get: { kelvin },set: { setKelvin($0) }),in: 1800...10000,step: 100)
                .tint(temperatureColor(kelvin)).accessibilityLabel("Approximate white temperature in Kelvin")
            HStack { Text("Warm"); Spacer(); Text("Cool") }.font(.caption2).foregroundStyle(.secondary)
            HStack(spacing: 8) {
                ForEach([2200,2700,3000,4000,5000,6500],id: \.self) { k in
                    Button { setKelvin(Double(k)) } label: {
                        VStack(spacing: 6) {
                            Circle().fill(temperatureColor(Double(k))).frame(width: 16,height: 16)
                            Text(String(k)).font(.system(size: 10,weight: .medium,design: .rounded))
                        }.frame(maxWidth: .infinity,minHeight: 44)
                            .background(whiteMode && Int(kelvin) == k ? accent.opacity(0.16) : .clear,in: RoundedRectangle(cornerRadius: 11))
                    }.buttonStyle(.plain).accessibilityLabel("\(k) Kelvin approximate RGB white")
                }
            }
            Text("RGB approximation · not calibrated CCT").font(.caption2).foregroundStyle(.secondary)
        }.padding(21).lumaGlass(tint: temperatureColor(kelvin).opacity(0.035))
    }
    private func mood(_ title: String,symbol: String,hex: String,level: Double) -> some View {
        Button { choose(hex,level: level) } label: {
            VStack(spacing: 8) { Image(systemName: symbol).font(.title3); Text(title).font(.caption.weight(.medium)) }
                .foregroundStyle(color(hex)).frame(maxWidth: .infinity).padding(.vertical,17)
                .lumaGlass(tint: color(hex).opacity(0.07))
        }.buttonStyle(.plain)
    }
    private var effectsPage: some View {
        VStack(alignment: .leading,spacing: 18) {
            VStack(alignment: .leading,spacing: 16) {
                HStack {
                    Label("Effect speed",systemImage: "speedometer")
                    Spacer()
                    Text(holdRequested ? "0 · hold attempt" : "\(Int(speed))%")
                        .monospacedDigit().foregroundStyle(.secondary)
                }.font(.subheadline)
                Slider(value: $speed,in: 1...100,step: 1)
                    .onChange(of: speed) { _ in
                        pending?.cancel(); holdRequested = false
                        if effect != nil && on { remote.setSpeed(Int(speed)) }
                    }.accessibilityLabel("Effect speed, moving the slider resumes motion")
                Button { requestHold() } label: {
                    Label(holdRequested ? "Resume animation" : "Try hold · speed 0",
                          systemImage: holdRequested ? "play.fill" : "pause.fill")
                        .frame(maxWidth: .infinity,minHeight: 44)
                }.buttonStyle(.borderedProminent).buttonBorderShape(.capsule)
                    .disabled(!remote.connected || effect == nil || !on)
                Text(holdRequested
                     ? "Speed 0 requested. Check the light: some firmware keeps moving slowly. This is not a confirmed freeze."
                     : "Start an effect below, then tap its card again to try holding the colours. Speed 0 may stop or slow it, depending on your controller.")
                    .font(.caption).foregroundStyle(.secondary)
                HStack {
                    Label("Brightness",systemImage: "sun.max")
                    Spacer()
                    Text("\(Int(brightness))%").monospacedDigit().foregroundStyle(.secondary)
                }.font(.subheadline)
                Slider(value: brightnessBinding,in: 0...100,step: 1)
                    .accessibilityLabel("Effect brightness")
                Text("Brightness sends only a dimming command. Hold behaviour depends on the light.")
                    .font(.caption2).foregroundStyle(.secondary)
                Button {
                    pending?.cancel(); holdRequested = false; effect = nil; on = true; send(); selectedTab = 0
                } label: { Label("Return to still colour",systemImage: "circle.fill").frame(minHeight: 44) }
                    .font(.subheadline)
            }.padding(21).lumaGlass()
            Text("Animated effects").font(.headline)
            Text("Factory animations, including two-colour fades. Try hold above to test speed 0; custom static left/right colours are not verified.")
                .font(.caption).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.flexible(),spacing: 16),GridItem(.flexible(),spacing: 16)],spacing: 16) {
                ForEach(effects) { e in
                    Button {
                        if effect == e.id && remote.connected && on { requestHold() }
                        else { startEffect(e.id) }
                    } label: {
                        VStack(alignment: .leading,spacing: 14) {
                            HStack { Image(systemName: e.symbol); Spacer(); if effect == e.id { Image(systemName: "checkmark.circle.fill") } }
                            RoundedRectangle(cornerRadius: 8).fill(LinearGradient(colors: e.colours,startPoint: .leading,endPoint: .trailing)).frame(height: 30)
                            Text(e.name).font(.caption.weight(.medium)).frame(maxWidth: .infinity,alignment: .leading)
                            if effect == e.id && remote.connected && on {
                                Label(holdRequested ? "Resume" : "Try hold",systemImage: holdRequested ? "play.fill" : "pause.fill")
                                    .font(.caption.weight(.semibold)).foregroundStyle(accent)
                            }
                        }.foregroundStyle(.primary).padding(16).lumaGlass(tint: effect == e.id ? accent.opacity(0.18) : .white.opacity(0.025))
                    }.buttonStyle(.plain).accessibilityAddTraits(effect == e.id ? .isSelected : [])
                        .accessibilityHint(effect == e.id ? "Tap again to request hold or resume" : "Start this animation")
                }
            }
        }
    }
    private var savedPage: some View {
        VStack(spacing: 14) {
            if favourites.isEmpty {
                Image(systemName: "heart").font(.system(size: 40,weight: .light)).foregroundStyle(accent).padding(.top,35)
                Text("Your favourite shades").font(.title3.weight(.semibold))
                Text("Choose a colour in Light, then tap Save.").font(.subheadline).foregroundStyle(.secondary)
            }
            ForEach(favourites,id: \.self) { h in
                HStack {
                    Button { choose(h); selectedTab = 0 } label: {
                        HStack(spacing: 14) { Circle().fill(color(h)).frame(width: 34,height: 34); Text("#" + h).font(.system(.subheadline,design: .monospaced)); Spacer() }
                    }.tint(.primary)
                    Button { savedColours = favourites.filter { $0 != h }.joined(separator: ",") } label: { Image(systemName: "trash").frame(width: 44,height: 44) }
                        .tint(.secondary).accessibilityLabel("Remove " + h)
                }.padding(14).lumaGlass(tint: color(h).opacity(0.06))
            }
        }
    }
    private var deviceSheet: some View {
        NavigationStack {
            List {
                Section { Text("Power on the LED and close Magic Lantern before connecting.").foregroundStyle(.secondary) }
                Section("Nearby controllers") {
                    ForEach(remote.devices,id: \.identifier) { p in
                        Button { remote.connect(p); showDevices = false } label: { Label(p.name ?? "LED controller",systemImage: "lightbulb.led") }
                    }
                    if remote.scanning { ProgressView("Scanning…") }
                    Text(remote.status).font(.caption).foregroundStyle(.secondary)
                    Button("Scan again") { remote.scan() }.disabled(remote.scanning)
                }
            }.navigationTitle("Connect light").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { showDevices = false } } }
        }.presentationDetents([.medium,.large])
    }
    private func componentBinding(_ index: Int) -> Binding<Double> {
        Binding(get: { Double(rgb[index]) },set: { value in
            var c = rgb; c[index] = UInt8(clamping: Int(value))
            colour = Color(red: Double(c[0])/255,green: Double(c[1])/255,blue: Double(c[2])/255)
            whiteMode = false; effect = nil; holdRequested = false; on = true; send()
        })
    }
    private var rgbSheet: some View {
        NavigationStack {
            Form {
                Section("RGB") {
                    ForEach(0..<3,id: \.self) { i in
                        VStack {
                            HStack { Text(["Red","Green","Blue"][i]); Spacer(); Text("\(rgb[i])").monospacedDigit().foregroundStyle(.secondary) }
                            Slider(value: componentBinding(i),in: 0...255,step: 1).tint([Color.red,.green,.blue][i]).accessibilityLabel(["Red","Green","Blue"][i])
                        }
                    }
                }
                Section("Hex colour") {
                    TextField("B600FF",text: $hexDraft).textInputAutocapitalization(.characters).autocorrectionDisabled()
                    Button("Apply hex colour") {
                        let h = hexDraft.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "#",with: "").uppercased()
                        guard h.count == 6, Int(h,radix: 16) != nil else { hexError = true; return }
                        hexError = false; choose(h); hexDraft = h
                    }
                    if hexError { Text("Enter six hex digits, for example B600FF.").font(.caption).foregroundStyle(.red) }
                }
            }.navigationTitle("Precise colour").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { showRGB = false } } }
        }.presentationDetents([.medium,.large])
    }
    private var helpSheet: some View {
        NavigationStack {
            Form {
                Section("Connect") {
                    Text("Power on your LED, close Magic Lantern and tap Connect. Select OA21 or your controller name.")
                }
                Section("What the screen shows") {
                    Text("Settings shown are the values requested by Luma. A successful Bluetooth write does not confirm the physical colour of the light.")
                }
                Section("Two colours") {
                    Text("Select an animated effect, then tap Try hold at the moment you like. This sends speed 0 only. Some firmware may merely slow the animation, so check the actual light. Resume sends your previous speed without restarting the effect. Brightness sends only a brightness command. There is no verified custom left/right segment command, frame readback or persistent frozen-scene save. Power cycling, reconnecting or selecting another effect can lose the frame.")
                }
                Section("White temperature") {
                    Text("1800–10000 K is an RGB approximation of warm to cool white. It does not drive a separate warm/cool white channel and is not a measured or calibrated colour temperature. Brightness stays independent.")
                }
                Section("Appearance") {
                    Text("Native Liquid Glass on iOS 26 and later. Earlier iOS versions use system material. Reduce Transparency is respected.")
                }
                Section { Text("Luma 1.3.0 · build 4").foregroundStyle(.secondary) }
            }.navigationTitle("About Luma").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { showHelp = false } } }
        }
    }
}
