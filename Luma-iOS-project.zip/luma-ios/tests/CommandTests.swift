import Foundation

@main
struct CommandTests {
    static func main() {
        let hold = LEDCommands.speed(0)
        precondition(hold == Data([0x7e,4,2,0,0xff,0xff,0xff,0,0xef]))
        precondition(LEDCommands.brightness(37) == Data([0x7e,4,1,37,1,0xff,0xff,0,0xef]))
        precondition(LEDCommands.speed(-1) == hold)
        precondition(LEDCommands.speed(101) == LEDCommands.speed(100))
        precondition(LEDCommands.brightness(-1) == LEDCommands.brightness(0))
        precondition(LEDCommands.brightness(101) == LEDCommands.brightness(100))
        let power = Data([0x7e,4,4,0xf0,0,1,0xff,0,0xef])
        let effect = Data([0x7e,5,3,204,6,0xff,0xff,0,0xef])
        var queue = [power,effect,LEDCommands.brightness(80),LEDCommands.speed(50)]
        queue = LEDCommands.replacingPendingAdjustment(queue,with:hold)
        queue = LEDCommands.replacingPendingAdjustment(queue,with:LEDCommands.brightness(37))
        precondition(queue == [power,effect,hold,LEDCommands.brightness(37)], "Dimming must preserve hold and effect setup")
        // Once setup is sent, hold and dim must not manufacture another mode,
        // colour, or power command that could restart the animation.
        var running: [Data] = []
        running = LEDCommands.replacingPendingAdjustment(running,with:hold)
        for level in 1...100 {
            running = LEDCommands.replacingPendingAdjustment(running,with:LEDCommands.brightness(level))
        }
        precondition(running == [hold,LEDCommands.brightness(100)])
        running = LEDCommands.replacingPendingAdjustment(running,with:LEDCommands.speed(50))
        precondition(running == [LEDCommands.brightness(100),LEDCommands.speed(50)])
        print("PASS: speed-zero packet, brightness independence, queue preservation, clamping and resume")
    }
}
